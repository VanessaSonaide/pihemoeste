<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Central do Doador</h1>

    <form action="<?php echo e(url('/ver')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button>Ver perfil</button>
    </form>

    <form action="<?php echo e(url('/doacao')); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button>Solicitar Doação</button>
    </form>

    <form action="<?php echo e(url('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button>Sair</button>
    </form>

</body>
</html><?php /**PATH C:\Users\20201101110059\Documents\Hemoeste\resources\views/doador/centraldoDoador.blade.php ENDPATH**/ ?>
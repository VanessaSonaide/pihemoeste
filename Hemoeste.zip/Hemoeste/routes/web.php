<?php

use App\Http\Controllers\HemoController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\VerifyEmailController;
use App\Models\User;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

    Route::get('/register', [RegisteredUserController::class, 'create']);

    Route::post('/register', [RegisteredUserController::class, 'store']);

    // Route::get('/login', [AuthenticatedSessionController::class, 'create']);

    // Route::post('/login', [AuthenticatedSessionController::class, 'store']);

    Route::get('/login', function () {
        return view('auth.login');
    });

    Route::post('/login', function () {
        return view('doador.centralDoDoador');
    });

    Route::get('/central', function () {
        return view('auth.login');
    });

    Route::post('/central', function () {
        return view('doador.centraldoDoador');
    });

    Route::get('/ver', function () {
        return view('auth.login');
    });

    Route::post('/ver', function () {
        $users = User::all();
        return view('doador.ver', [
            'users' => $users, ]);
    });

    Route::get('/editar/{id}', [HemoController::class, 'edit']);

    Route::post('/editar/{id}', function() {
        $users = User::find ($id);
        return view('doador.editar', [
            'users' => $users, ]);
        });

    // Route::get('/ver', [HemoController::class, 'create']);
    // Route::post('/ver', [HemoController::class, 'store']);


    // require __DIR__ . '/auth.php';

Route::get('/', function () {
    return view('welcome');
});
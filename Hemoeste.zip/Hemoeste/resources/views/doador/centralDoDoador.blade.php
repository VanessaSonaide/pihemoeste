<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Central do Doador</h1>

    <form action="{{url('/ver')}}" method="POST">
        @csrf
        <button>Ver perfil</button>
    </form>

    <form action="{{url('/doacao')}}" method="GET">
        @csrf
        <button>Solicitar Doação</button>
    </form>

    <form action="{{url('logout')}}" method="POST">
        @csrf
        <button>Sair</button>
    </form>

</body>
</html>